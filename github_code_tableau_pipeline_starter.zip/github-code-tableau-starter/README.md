# GitHub → Code → Tableau (Pipeline Starter)

This repo is a **plumbing starter**: GitHub hosts your project, a tiny Python script
creates demo CSVs, GitHub Actions publishes a **Pages** site that can embed your **Tableau Public** story.
The data content is just placeholder—you can swap it later.

## How to use (10–15 min, no command line required)
1) **Create a public repo** on GitHub (e.g., `risk-portfolio`).
2) **Upload these files** (keep the folders: `.github/`, `scripts/`, `docs/`).
3) Go to **Settings → Pages** and set **Build and deployment = GitHub Actions**.
   - The included workflow (`.github/workflows/pages.yml`) will run automatically.
4) When the workflow turns green, click **View deployment** to open your **site URL**.
   - You’ll see a page with links to CSVs and a Tableau iframe placeholder.
5) Open **Tableau Public**, connect to the CSVs <em>from your local copy first</em>, build a small story, **Publish**, and copy the **Embed** URL.
6) Back on GitHub, edit `docs/index.html` and replace the `src="..."` with your Tableau embed link, then **Commit**.
   - Refresh the site URL → your Tableau story appears on the page.

### Files
- `scripts/make_demo_data.py` — generates 3 CSVs into `docs/data/`
- `.github/workflows/pages.yml` — builds the site on every push (and on demand)
- `docs/index.html` — your public site; paste Tableau embed URL here
- `docs/data/*.csv` — auto-created placeholders (safe to publish)

### Notes
- **Tableau Public does not auto-refresh from GitHub** — when your CSVs change, you usually re-publish the workbook. That’s fine for a portfolio.
- Keep real data out of the repo; these CSVs are synthetic placeholders.
- Later, replace `scripts/make_demo_data.py` with your real pipeline step.

© 2025 — Starter
